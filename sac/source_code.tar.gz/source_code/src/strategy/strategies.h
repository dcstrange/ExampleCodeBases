#ifndef _STRATEGIES_H_
#define _STRATEGIES_H_

#include "lru_private.h"
#include "most.h"
#include "most_cdc.h"
#include "sac.h"

//#include "oldpore.h"
//#include "pv3.h"

#endif // _STRATEGIES_H_
