## There are some things i write down. Search those keyword for a quick locating. 
*-- AUTHOR: DIANSEN SUN. (diansensun@gmail.com)*

### ***ugly way***
There are few of functions which is not given in properate way, even kind of ugly way. 

So i annotate them by: `// >< #ugly way.` *Have to modify them into a elegant way*

### ***version***
 I use the `[alpha/beta]` to mark those functional modules which are in development.

### ***About the naming rules of variables..***
Till now, sorry, i have no idea of how to name a variables according to some specific consistent rule. 

### *** about Branch ***
I usually `git checkout -b` a new branch for temp test, each of them has the following features required attention:
- Base Branch: Every issue branch has a base branch from which to build extra modification. 
- Extra Modifications: we use the `<*FLAG*>` as comment in each modified line.