#!/bin/bash

# 用法提示
usage() {
    echo "Usage: $0 -u <username> -p <password> [-P <port>] [--url <url>]"
    exit 1
}

# 初始化默认值
URL="bolt://localhost"

# 使用 getopt 解析短选项和长选项
ARGS=$(getopt -o u:p:P: --long url: -n "$0" -- "$@")
if [ $? -ne 0 ]; then
    # 如果参数解析失败，打印用法提示并退出
    usage
fi

# 重新整理参数顺序
eval set -- "$ARGS"

# 解析选项
while true; do
    case "$1" in
        -u) USERNAME="$2"; shift 2 ;;
        -p) PASSWORD="$2"; shift 2 ;;
        -P) PORT="$2"; shift 2 ;;
        --url) URL="$2"; shift 2 ;;
        --) shift; break ;;
        *) usage ;;
    esac
done

if [ -z "$USERNAME" ] || [ -z "$PASSWORD" ]; then
    usage
fi

if [ -z "$URL" ]; then
    URL="bolt://localhost" # 默认主机地址
fi

if [ -n "$PORT" ]; then
    URL="$URL:$PORT"
fi

echo "run: cypher-shell -u {$USERNAME} -p {$PASSWORD} -a {$URL}"
echo "开始创建唯一性约束..."

# --------------------------------------------------------
# 0.1 创建 File 唯一性约束
cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "$URL" <<EOF
CREATE CONSTRAINT files_id IF NOT EXISTS
FOR (f:File)
REQUIRE f.id IS UNIQUE;
EOF

# --------------------------------------------------------
# 0.2 创建 Function 唯一性约束
cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "$URL" <<EOF
CREATE CONSTRAINT functions_id IF NOT EXISTS
FOR (fn:Function)
REQUIRE fn.id IS UNIQUE;
EOF

# --------------------------------------------------------
# 0.3 创建 Global 唯一性约束
cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "$URL" <<EOF
CREATE CONSTRAINT globals_id IF NOT EXISTS
FOR (g:Global)
REQUIRE g.id IS UNIQUE;
EOF

# --------------------------------------------------------
# 0.4 创建 Type 唯一性约束
cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "$URL" <<EOF
CREATE CONSTRAINT types_id IF NOT EXISTS
FOR (t:Type)
REQUIRE t.id IS UNIQUE;
EOF

# --------------------------------------------------------
# 0.5 创建 Macro 唯一性约束
cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "$URL" <<EOF
CREATE CONSTRAINT macros_id IF NOT EXISTS
FOR (m:Macro)
REQUIRE m.id IS UNIQUE;
EOF

echo "唯一性约束创建完毕。"