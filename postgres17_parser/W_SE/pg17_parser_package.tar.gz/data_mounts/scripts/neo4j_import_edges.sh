#!/bin/bash
# import_edges.sh - 批量执行多个 Cypher 语句（通过 cypher-shell 执行 CSV/JSON 导入关系）

# 用法提示
usage() {
    echo "Usage: $0 -u username -p password -P port [-f format]"
    echo "  -u  Neo4j用户名"
    echo "  -p  Neo4j密码"
    echo "  -P  Neo4j端口号"
    echo "  -f  导入文件格式 (csv 或 json，默认为 csv)"
    exit 1
}

# 解析命令行参数
FORMAT="json"  # 默认格式为CSV
while getopts "u:p:P:f:" opt; do
    case $opt in
        u) USERNAME="$OPTARG" ;;
        p) PASSWORD="$OPTARG" ;;
        P) PORT="$OPTARG" ;;
        f) FORMAT="$OPTARG" ;;
        *) usage ;;
    esac
done

if [ -z "$USERNAME" ] || [ -z "$PASSWORD" ] || [ -z "$PORT" ]; then
    usage
fi

# 验证格式参数
if [ "$FORMAT" != "csv" ] && [ "$FORMAT" != "json" ]; then
    echo "错误: 文件格式必须为 'csv' 或 'json'"
    usage
fi

HOST="localhost"  # 默认主机地址

echo "开始批量加载 $FORMAT 数据并导入关系数据..."

# 如果使用JSON格式，检查APOC是否可用
if [ "$FORMAT" = "json" ]; then
    APOC_CHECK=$(cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" --format plain "SHOW PROCEDURES YIELD name WHERE name STARTS WITH 'apoc' RETURN count(*) AS count;")
    
    if [[ $APOC_CHECK == *"0"* ]]; then
        echo "错误: 未检测到APOC扩展库。请在Neo4j中安装APOC扩展库以支持JSON导入。"
        exit 1
    fi
fi

# 根据格式选择不同的导入方法
if [ "$FORMAT" = "csv" ]; then
    # CSV导入方法 - 原有代码
    
    # 1. file_defines_function.csv - 建立 DEFINES_FUNCTION 关系
    echo "执行：file_defines_function.csv (DEFINES_FUNCTION)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///file_defines_function.csv' AS row
    MATCH (f:File {rdb_id: toInteger(row.start_id)}),
          (fn:Function {rdb_id: toInteger(row.end_id)})
    MERGE (f)-[:DEFINES_FUNCTION]->(fn);
EOF

    # 2. file_declares_function.csv - 建立 DECLARES_FUNCTION 关系
    echo "执行：file_declares_function.csv (DECLARES_FUNCTION)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///file_declares_function.csv' AS row
    MATCH (f:File {rdb_id: toInteger(row.start_id)}),
          (fn:Function {rdb_id: toInteger(row.end_id)})
    MERGE (f)-[:DECLARES_FUNCTION]->(fn);
EOF

    # 3. file_defines_global.csv - 建立 DEFINES_GLOBAL 关系
    echo "执行：file_defines_global.csv (DEFINES_GLOBAL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///file_defines_global.csv' AS row
    MATCH (f:File {rdb_id: toInteger(row.start_id)}),
          (g:Global {rdb_id: toInteger(row.end_id)})
    MERGE (f)-[:DEFINES_GLOBAL]->(g);
EOF

    # 4. file_declares_global.csv - 建立 DECLARES_GLOBAL 关系
    echo "执行：file_declares_global.csv (DECLARES_GLOBAL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///file_declares_global.csv' AS row
    MATCH (f:File {rdb_id: toInteger(row.start_id)}),
          (g:Global {rdb_id: toInteger(row.end_id)})
    MERGE (f)-[:DECLARES_GLOBAL]->(g);
EOF

    # 5. file_defines_type.csv - 建立 DEFINES_TYPE 关系
    echo "执行：file_defines_type.csv (DEFINES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///file_defines_type.csv' AS row
    MATCH (f:File {rdb_id: toInteger(row.start_id)}),
          (t:Type {rdb_id: toInteger(row.end_id)})
    MERGE (f)-[:DEFINES_TYPE]->(t);
EOF

    # 6. file_declares_type.csv - 建立 DECLARES_TYPE 关系
    echo "执行：file_declares_type.csv (DECLARES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///file_declares_type.csv' AS row
    MATCH (f:File {rdb_id: toInteger(row.start_id)}),
          (t:Type {rdb_id: toInteger(row.end_id)})
    MERGE (f)-[:DECLARES_TYPE]->(t);
EOF

    # 7. file_defines_macro.csv - 建立 DEFINES_MACRO 关系
    echo "执行：file_defines_macro.csv (DEFINES_MACRO)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///file_defines_macro.csv' AS row
    MATCH (f:File {rdb_id: toInteger(row.start_id)}),
          (m:Macro {rdb_id: toInteger(row.end_id)})
    MERGE (f)-[:DEFINES_MACRO]->(m);
EOF

    # 8. file_includes_file.csv - 建立 INCLUDES_FILE 关系
    echo "执行：file_includes_file.csv (INCLUDES_FILE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///file_includes_file.csv' AS row
    MATCH (f1:File {rdb_id: toInteger(row.start_id)}),
          (f2:File {rdb_id: toInteger(row.end_id)})
    MERGE (f1)-[:INCLUDES_FILE]->(f2);
EOF

    # 9. function_function_rel.csv - 建立关系
    echo "执行：function_function_rel.csv (FUNCTION_REL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///function_function_rel.csv' AS row
    MATCH (caller:Function {rdb_id: toInteger(row.start_id)}),
          (callee:Function {rdb_id: toInteger(row.end_id)})
    FOREACH(ignoreMe IN CASE WHEN row.relation_type = 'invokes' THEN [1] ELSE [] END |
      MERGE (caller)-[:INVOKES]->(callee))
    FOREACH(ignoreMe IN CASE WHEN row.relation_type = 'ref' THEN [1] ELSE [] END |
      MERGE (caller)-[:REF_AS_POINTER]->(callee))
    FOREACH(ignoreMe IN CASE WHEN row.relation_type = 'implemented_by' THEN [1] ELSE [] END |
      MERGE (caller)-[:IMPLEMENTED_BY]->(callee))
EOF

    # 10. function_uses_global.csv - 建立 USES_GLOBAL 关系（Function -> Global）
    echo "执行：function_uses_global.csv (USES_GLOBAL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///function_uses_global.csv' AS row
    MATCH (fn:Function {rdb_id: toInteger(row.start_id)}),
          (g:Global {rdb_id: toInteger(row.end_id)})
    MERGE (fn)-[r:USES_GLOBAL]->(g)
    ON CREATE SET r.usage_type = row.usage_type;
EOF

    # 11. function_uses_type.csv - 建立 USES_TYPE 关系（Function -> Type）
    echo "执行：function_uses_type.csv (USES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///function_uses_type.csv' AS row
    MATCH (fn:Function {rdb_id: toInteger(row.start_id)}),
          (t:Type {rdb_id: toInteger(row.end_id)})
    MERGE (fn)-[r:USES_TYPE]->(t)
    ON CREATE SET r.usage_type = row.usage_type;
EOF

    # 12. function_uses_macro.csv - 建立 USES_MACRO 关系（Function -> Macro）
    echo "执行：function_uses_macro.csv (USES_MACRO)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///function_uses_macro.csv' AS row
    MATCH (fn:Function {rdb_id: toInteger(row.start_id)}),
          (m:Macro {rdb_id: toInteger(row.end_id)})
    MERGE (fn)-[r:USES_MACRO]->(m)
    ON CREATE SET r.usage_type = row.usage_type;
EOF

    # 13. global_uses_function.csv - 建立 USES_FUNCTION 关系（Global -> Function）
    echo "执行：global_uses_function.csv (USES_FUNCTION)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///global_uses_function.csv' AS row
    MATCH (g:Global {rdb_id: toInteger(row.start_id)}),
          (fn:Function {rdb_id: toInteger(row.end_id)})
    MERGE (g)-[r:USES_FUNCTION]->(fn)
    ON CREATE SET r.usage_type = row.usage_type;
EOF

    # 14. global_uses_global.csv - 建立 USES_GLOBAL 关系（Global -> Global）
    echo "执行：global_uses_global.csv (USES_GLOBAL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///global_uses_global.csv' AS row
    MATCH (g1:Global {rdb_id: toInteger(row.start_id)}),
          (g2:Global {rdb_id: toInteger(row.end_id)})
    MERGE (g1)-[r:USES_GLOBAL]->(g2)
    ON CREATE SET r.usage_type = row.usage_type;
EOF

    # 15. global_uses_type.csv - 建立 USES_TYPE 关系（Global -> Type）
    echo "执行：global_uses_type.csv (USES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///global_uses_type.csv' AS row
    MATCH (g:Global {rdb_id: toInteger(row.start_id)}),
          (t:Type {rdb_id: toInteger(row.end_id)})
    MERGE (g)-[r:USES_TYPE]->(t)
    ON CREATE SET r.usage_type = row.usage_type;
EOF

    # 16. global_uses_macro.csv - 建立 USES_MACRO 关系（Global -> Macro）
    echo "执行：global_uses_macro.csv (USES_MACRO)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///global_uses_macro.csv' AS row
    MATCH (g:Global {rdb_id: toInteger(row.start_id)}),
          (m:Macro {rdb_id: toInteger(row.end_id)})
    MERGE (g)-[r:USES_MACRO]->(m)
    ON CREATE SET r.usage_type = row.usage_type;
EOF

    # 17. type_uses_type.csv - 建立 USES_TYPE 关系（Type -> Type），并设置 usage_desc 属性
    echo "执行：type_uses_type.csv (USES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///type_uses_type.csv' AS row
    MATCH (t1:Type {rdb_id: toInteger(row.start_id)}),
          (t2:Type {rdb_id: toInteger(row.end_id)})
    MERGE (t1)-[r:USES_TYPE]->(t2)
    ON CREATE SET r.usage_desc = row.usage_desc;
EOF

    # 18. type_uses_macro.csv - 建立 USES_MACRO 关系（Type -> Macro）
    echo "执行：type_uses_macro.csv (USES_MACRO)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///type_uses_macro.csv' AS row
    MATCH (t:Type {rdb_id: toInteger(row.start_id)}),
          (m:Macro {rdb_id: toInteger(row.end_id)})
    MERGE (t)-[r:USES_MACRO]->(m)
    ON CREATE SET r.usage_type = row.usage_type;
EOF

else
    # JSON导入方法 - 使用APOC扩展库
    
    # 1. file_defines_function.json - 建立 DEFINES_FUNCTION 关系
    echo "执行：file_defines_function.json (DEFINES_FUNCTION)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///file_defines_function.json') YIELD value
    MATCH (f:File {rdb_id: toInteger(value.start_id)}),
          (fn:Function {rdb_id: toInteger(value.end_id)})
    MERGE (f)-[:DEFINES_FUNCTION]->(fn);
EOF

    # 2. file_declares_function.json - 建立 DECLARES_FUNCTION 关系
    echo "执行：file_declares_function.json (DECLARES_FUNCTION)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///file_declares_function.json') YIELD value
    MATCH (f:File {rdb_id: toInteger(value.start_id)}),
          (fn:Function {rdb_id: toInteger(value.end_id)})
    MERGE (f)-[:DECLARES_FUNCTION]->(fn);
EOF

    # 3. file_defines_global.json - 建立 DEFINES_GLOBAL 关系
    echo "执行：file_defines_global.json (DEFINES_GLOBAL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///file_defines_global.json') YIELD value
    MATCH (f:File {rdb_id: toInteger(value.start_id)}),
          (g:Global {rdb_id: toInteger(value.end_id)})
    MERGE (f)-[:DEFINES_GLOBAL]->(g);
EOF

    # 4. file_declares_global.json - 建立 DECLARES_GLOBAL 关系
    echo "执行：file_declares_global.json (DECLARES_GLOBAL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///file_declares_global.json') YIELD value
    MATCH (f:File {rdb_id: toInteger(value.start_id)}),
          (g:Global {rdb_id: toInteger(value.end_id)})
    MERGE (f)-[:DECLARES_GLOBAL]->(g);
EOF

    # 5. file_defines_type.json - 建立 DEFINES_TYPE 关系
    echo "执行：file_defines_type.json (DEFINES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///file_defines_type.json') YIELD value
    MATCH (f:File {rdb_id: toInteger(value.start_id)}),
          (t:Type {rdb_id: toInteger(value.end_id)})
    MERGE (f)-[:DEFINES_TYPE]->(t);
EOF

    # 6. file_declares_type.json - 建立 DECLARES_TYPE 关系
    echo "执行：file_declares_type.json (DECLARES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///file_declares_type.json') YIELD value
    MATCH (f:File {rdb_id: toInteger(value.start_id)}),
          (t:Type {rdb_id: toInteger(value.end_id)})
    MERGE (f)-[:DECLARES_TYPE]->(t);
EOF

    # 7. file_defines_macro.json - 建立 DEFINES_MACRO 关系
    echo "执行：file_defines_macro.json (DEFINES_MACRO)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///file_defines_macro.json') YIELD value
    MATCH (f:File {rdb_id: toInteger(value.start_id)}),
          (m:Macro {rdb_id: toInteger(value.end_id)})
    MERGE (f)-[:DEFINES_MACRO]->(m);
EOF

    # 8. file_includes_file.json - 建立 INCLUDES_FILE 关系
    echo "执行：file_includes_file.json (INCLUDES_FILE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///file_includes_file.json') YIELD value
    MATCH (f1:File {rdb_id: toInteger(value.start_id)}),
          (f2:File {rdb_id: toInteger(value.end_id)})
    MERGE (f1)-[:INCLUDES_FILE]->(f2);
EOF

    # 9. function_function_rel.json - 建立关系
    echo "执行：function_function_rel.json (FUNCTION_REL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///function_function_rel.json') YIELD value
    MATCH (caller:Function {rdb_id: toInteger(value.start_id)}),
          (callee:Function {rdb_id: toInteger(value.end_id)})
    FOREACH(ignoreMe IN CASE WHEN value.relation_type = 'invokes' THEN [1] ELSE [] END |
      MERGE (caller)-[:INVOKES]->(callee))
    FOREACH(ignoreMe IN CASE WHEN value.relation_type = 'ref' THEN [1] ELSE [] END |
      MERGE (caller)-[:REF_AS_POINTER]->(callee))
    FOREACH(ignoreMe IN CASE WHEN value.relation_type = 'implemented_by' THEN [1] ELSE [] END |
      MERGE (caller)-[:IMPLEMENTED_BY]->(callee))
EOF

    # 10. function_uses_global.json - 建立 USES_GLOBAL 关系（Function -> Global）
    echo "执行：function_uses_global.json (USES_GLOBAL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///function_uses_global.json') YIELD value
    MATCH (fn:Function {rdb_id: toInteger(value.start_id)}),
          (g:Global {rdb_id: toInteger(value.end_id)})
    MERGE (fn)-[r:USES_GLOBAL]->(g)
    ON CREATE SET r.usage_type = value.usage_type;
EOF

    # 11. function_uses_type.json - 建立 USES_TYPE 关系（Function -> Type）
    echo "执行：function_uses_type.json (USES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///function_uses_type.json') YIELD value
    MATCH (fn:Function {rdb_id: toInteger(value.start_id)}),
          (t:Type {rdb_id: toInteger(value.end_id)})
    MERGE (fn)-[r:USES_TYPE]->(t)
    ON CREATE SET r.usage_type = value.usage_type;
EOF

    # 12. function_uses_macro.json - 建立 USES_MACRO 关系（Function -> Macro）
    echo "执行：function_uses_macro.json (USES_MACRO)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///function_uses_macro.json') YIELD value
    MATCH (fn:Function {rdb_id: toInteger(value.start_id)}),
          (m:Macro {rdb_id: toInteger(value.end_id)})
    MERGE (fn)-[r:USES_MACRO]->(m)
    ON CREATE SET r.usage_type = value.usage_type;
EOF

    # 13. global_uses_function.json - 建立 USES_FUNCTION 关系（Global -> Function）
    echo "执行：global_uses_function.json (USES_FUNCTION)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///global_uses_function.json') YIELD value
    MATCH (g:Global {rdb_id: toInteger(value.start_id)}),
          (fn:Function {rdb_id: toInteger(value.end_id)})
    MERGE (g)-[r:USES_FUNCTION]->(fn)
    ON CREATE SET r.usage_type = value.usage_type;
EOF

    # 14. global_uses_global.json - 建立 USES_GLOBAL 关系（Global -> Global）
    echo "执行：global_uses_global.json (USES_GLOBAL)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///global_uses_global.json') YIELD value
    MATCH (g1:Global {rdb_id: toInteger(value.start_id)}),
        (g2:Global {rdb_id: toInteger(value.end_id)})
    FOREACH(ignoreMe IN CASE WHEN value.relation_type = 'uses' THEN [1] ELSE [] END |
        MERGE (g1)-[:USES]->(g2))
    FOREACH(ignoreMe IN CASE WHEN value.relation_type = 'implemented_by' THEN [1] ELSE [] END |
        MERGE (g1)-[:IMPLEMENTED_BY]->(g2))
EOF

    # 15. global_uses_type.json - 建立 USES_TYPE 关系（Global -> Type）
    echo "执行：global_uses_type.json (USES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///global_uses_type.json') YIELD value
    MATCH (g:Global {rdb_id: toInteger(value.start_id)}),
          (t:Type {rdb_id: toInteger(value.end_id)})
    MERGE (g)-[r:USES_TYPE]->(t)
    ON CREATE SET r.usage_type = value.usage_type;
EOF

    # 16. global_uses_macro.json - 建立 USES_MACRO 关系（Global -> Macro）
    echo "执行：global_uses_macro.json (USES_MACRO)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///global_uses_macro.json') YIELD value
    MATCH (g:Global {rdb_id: toInteger(value.start_id)}),
          (m:Macro {rdb_id: toInteger(value.end_id)})
    MERGE (g)-[r:USES_MACRO]->(m)
    ON CREATE SET r.usage_type = value.usage_type;
EOF

    # 17. type_uses_type.json - 建立 USES_TYPE 关系（Type -> Type），并设置 usage_desc 属性
    echo "执行：type_uses_type.json (USES_TYPE)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///type_uses_type.json') YIELD value
    MATCH (t1:Type {rdb_id: toInteger(value.start_id)}),
        (t2:Type {rdb_id: toInteger(value.end_id)})
    FOREACH(ignoreMe IN CASE WHEN value.relation_type = 'uses' THEN [1] ELSE [] END |
    MERGE (t1)-[:USES]->(t2))
    FOREACH(ignoreMe IN CASE WHEN value.relation_type = 'implemented_by' THEN [1] ELSE [] END |
    MERGE (t1)-[:IMPLEMENTED_BY]->(t2))
    FOREACH(ignoreMe IN CASE WHEN value.relation_type = 'contains' THEN [1] ELSE [] END |
    MERGE (t1)-[:CONTAINS]->(t2))
EOF

    # 18. type_uses_macro.json - 建立 USES_MACRO 关系（Type -> Macro）
    echo "执行：type_uses_macro.json (USES_MACRO)"
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///type_uses_macro.json') YIELD value
    MATCH (t:Type {rdb_id: toInteger(value.start_id)}),
          (m:Macro {rdb_id: toInteger(value.end_id)})
    MERGE (t)-[r:USES_MACRO]->(m)
    ON CREATE SET r.usage_type = value.usage_type;
EOF

fi

echo "所有批处理查询已执行完成。"