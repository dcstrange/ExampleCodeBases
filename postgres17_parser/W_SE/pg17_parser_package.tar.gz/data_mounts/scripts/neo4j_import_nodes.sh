#!/bin/bash

# 用法提示
usage() {
    echo "Usage: $0 -u username -p password -P port [-f format]"
    echo "  -u  Neo4j用户名"
    echo "  -p  Neo4j密码"
    echo "  -P  Neo4j端口号"
    echo "  -f  导入文件格式 (csv 或 json，默认为 csv)"
    exit 1
}

# 解析命令行参数
FORMAT="json"  # 默认格式为CSV
while getopts "u:p:P:f:" opt; do
    case $opt in
        u) USERNAME="$OPTARG" ;;
        p) PASSWORD="$OPTARG" ;;
        P) PORT="$OPTARG" ;;
        f) FORMAT="$OPTARG" ;;
        *) usage ;;
    esac
done

if [ -z "$USERNAME" ] || [ -z "$PASSWORD" ] || [ -z "$PORT" ]; then
    usage
fi

# 验证格式参数
if [ "$FORMAT" != "csv" ] && [ "$FORMAT" != "json" ]; then
    echo "错误: 文件格式必须为 'csv' 或 'json'"
    usage
fi

HOST="localhost"  # 默认主机地址

echo "开始通过 $FORMAT 导入节点数据..."

# 根据格式选择不同的导入方法
if [ "$FORMAT" = "csv" ]; then
    # --------------------------------------------------------
    # CSV导入方法 - 保持原有逻辑
    # 1.1 导入 files 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///files.csv' AS row
    MERGE (f:File {rdb_id: toInteger(row.id) })
    ON CREATE SET
      f.name                  = row.path,
      f.file_hash            = row.file_hash,
      f.source_code          = row.source_code,
      f.annotation           = row.annotation,
      f.semantic_explanation = row.semantic_explanation
EOF

    # --------------------------------------------------------
    # 1.2 导入 functions 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///functions.csv' AS row
    MERGE (fn:Function {rdb_id: toInteger(row.id) })
    ON CREATE SET
      fn.name                 = row.name,
      fn.def_loc             = row.def_loc,
      fn.decl_loc            = row.decl_loc,
      fn.ret_type            = row.ret_type,
      fn.is_static           = (row.is_static = 't'),
      fn.op_source           = row.op_source,
      fn.source_code         = row.source_code,
      fn.annotation          = row.annotation,
      fn.semantic_explanation = row.semantic_explanation
EOF

    # --------------------------------------------------------
    # 1.3 导入 globals 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///globals.csv' AS row
    MERGE (g:Global {rdb_id: toInteger(row.id) })
    ON CREATE SET
      g.name                  = row.name,
      g.def_loc              = row.def_loc,
      g.decl_loc             = row.decl_loc,
      g.is_static            = (row.is_static = 't'),
      g.is_extern            = (row.is_extern = 't'),
      g.op_source            = row.op_source,
      g.source_code          = row.source_code,
      g.annotation           = row.annotation,
      g.semantic_explanation = row.semantic_explanation
EOF

    # --------------------------------------------------------
    # 1.4 导入 types 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///types.csv' AS row
    MERGE (t:Type {rdb_id: toInteger(row.id) })
    ON CREATE SET
      t.name                  = row.name,
      t.def_loc              = row.def_loc,
      t.decl_loc             = row.decl_loc,
      t.kind                 = row.kind,
      t.is_definition        = (row.is_definition = 't'),
      t.is_function_pointer  = (row.is_function_pointer = 't'),
      t.op_source            = row.op_source,
      t.source_code          = row.source_code,
      t.annotation           = row.annotation,
      t.semantic_explanation = row.semantic_explanation
EOF

    # --------------------------------------------------------
    # 1.5 导入 macros 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    LOAD CSV WITH HEADERS FROM 'file:///macros.csv' AS row
    MERGE (m:Macro {rdb_id: toInteger(row.id) })
    ON CREATE SET
      m.name                  = row.name,
      m.def_loc              = row.def_loc,
      m.content              = row.content,
      m.source_code          = row.source_code,
      m.annotation           = row.annotation,
      m.semantic_explanation = row.semantic_explanation
EOF

else
    # --------------------------------------------------------
    # JSON导入方法 - 使用APOC扩展库
    # 注意：需要Neo4j安装APOC扩展库
    
    # 检查APOC是否可用
    APOC_CHECK=$(cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" --format plain "SHOW PROCEDURES YIELD name WHERE name STARTS WITH 'apoc' RETURN count(*) AS count;")
    
    if [[ $APOC_CHECK == *"0"* ]]; then
        echo "错误: 未检测到APOC扩展库。请在Neo4j中安装APOC扩展库以支持JSON导入。"
        exit 1
    fi
    
    # 1.1 导入 files 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///files.json') YIELD value
    MERGE (f:File {rdb_id: toInteger(value.id) })
    ON CREATE SET
      f.name                  = value.path,
      f.file_hash            = value.file_hash,
      f.source_code          = value.source_code,
      f.annotation           = value.annotation,
      f.semantic_explanation = value.semantic_explanation
EOF
    echo "导入 files 节点完成" 
    

    # 1.2 导入 functions 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///functions.json') YIELD value
    MERGE (fn:Function {rdb_id: toInteger(value.id) })
    ON CREATE SET
      fn.name                 = value.name,
      fn.def_loc             = value.def_loc,
      fn.decl_loc            = value.decl_loc,
      fn.ret_type            = value.ret_type,
      fn.is_static           = value.is_static,
      fn.op_source           = value.op_source,
      fn.source_code         = value.source_code,
      fn.annotation          = value.annotation,
      fn.semantic_explanation = value.semantic_explanation
EOF
    echo "导入 functions 节点完成"

    # 1.3 导入 globals 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///globals.json') YIELD value
    MERGE (g:Global {rdb_id: toInteger(value.id) })
    ON CREATE SET
      g.name                  = value.name,
      g.def_loc              = value.def_loc,
      g.decl_loc             = value.decl_loc,
      g.is_static            = value.is_static,
      g.is_extern            = value.is_extern,
      g.op_source            = value.op_source,
      g.source_code          = value.source_code,
      g.annotation           = value.annotation,
      g.semantic_explanation = value.semantic_explanation
EOF
    echo "导入 globals 节点完成"

    # 1.4 导入 types 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///types.json') YIELD value
    MERGE (t:Type {rdb_id: toInteger(value.id) })
    ON CREATE SET
      t.name                  = value.name,
      t.def_loc              = value.def_loc,
      t.decl_loc             = value.decl_loc,
      t.kind                 = value.kind,
      t.is_definition        = value.is_definition,
      t.is_function_pointer  = value.is_function_pointer,
      t.op_source            = value.op_source,
      t.source_code          = value.source_code,
      t.annotation           = value.annotation,
      t.semantic_explanation = value.semantic_explanation
EOF

    # 1.5 导入 macros 节点
    cypher-shell -u "$USERNAME" -p "$PASSWORD" -a "bolt://$HOST:$PORT" <<EOF
    CALL apoc.load.json('file:///macros.json') YIELD value
    MERGE (m:Macro {rdb_id: toInteger(value.id) })
    ON CREATE SET
      m.name                  = value.name,
      m.def_loc              = value.def_loc,
      m.content              = value.content,
      m.source_code          = value.source_code,
      m.annotation           = value.annotation,
      m.semantic_explanation = value.semantic_explanation
EOF
    echo "导入 macros 节点完成"
fi

echo "节点数据已导入完成。"