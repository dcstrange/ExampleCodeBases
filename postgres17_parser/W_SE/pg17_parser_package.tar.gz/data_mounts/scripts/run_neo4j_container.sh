#!/bin/bash

# 使用方法说明
usage() {
    echo "用法: $0 <local_path> <container_name> [http_port] [bolt_port]"
    echo "  <local_path>      - 容器数据存储的本地路径"
    echo "  <container_name>  - 容器名称"
    echo "  [http_port]       - 映射到容器 HTTP 端口（默认: 7674）"
    echo "  [bolt_port]       - 映射到容器 Bolt 端口（默认: 7689）"
    exit 1
}

# 检查参数个数
if [ "$#" -lt 2 ] || [ "$#" -gt 4 ]; then
    usage
fi
SCRIPTS_DIR="$(cd "$(dirname "$0")" && pwd)"
# 获取参数
LOCAL_PATH=$1
CONTAINER_NAME=$2
HTTP_PORT=${3:-7674}  # 如果第三个参数不存在，默认使用7674
BOLT_PORT=${4:-7689}  # 如果第四个参数不存在，默认使用7689

# 定义需要检查的目录
DIRS=("data" "logs" "backups" "import")

# 循环检查并创建目录
for DIR in "${DIRS[@]}"; do
    TARGET_DIR="${LOCAL_PATH}/${CONTAINER_NAME}/${DIR}"
    if [ ! -d "$TARGET_DIR" ]; then
        mkdir -p "$TARGET_DIR"
        if [ $? -eq 0 ]; then
            echo "已创建目录: $TARGET_DIR"
        else
            echo "错误: 无法创建目录 $TARGET_DIR"
            exit 1
        fi
    else
        echo "目录已存在: $TARGET_DIR"
    fi
done

# 检查是否已存在同名容器
EXISTING_CONTAINER=$(sudo docker ps -a --filter "name=^/${CONTAINER_NAME}$" --format "{{.Names}}")
if [ "$EXISTING_CONTAINER" == "$CONTAINER_NAME" ]; then
    echo "错误: 容器名称 '$CONTAINER_NAME' 已存在。请选择其他名称或先删除现有容器。"
    exit 1
fi

# 检查端口是否被占用
check_port() {
    PORT=$1
    if sudo netstat -tunlp | grep ":$PORT " > /dev/null; then
        echo "错误: 端口 $PORT 已被占用。请选择其他端口或释放该端口。"
        exit 1
    fi
}

check_port "$HTTP_PORT"
check_port "$BOLT_PORT"

# 运行 Docker 容器
sudo docker run -d --name "${CONTAINER_NAME}" \
    -p "${HTTP_PORT}":7474 \
    -p "${BOLT_PORT}":7687 \
    -v "${LOCAL_PATH}/${CONTAINER_NAME}/data":/data \
    -v "${LOCAL_PATH}/${CONTAINER_NAME}/logs":/logs \
    -v "${LOCAL_PATH}/${CONTAINER_NAME}/backups":/backups \
    -v "${LOCAL_PATH}/${CONTAINER_NAME}/import":/var/lib/neo4j/import \
    -v "${SCRIPTS_DIR}":/scripts:ro \
    -e NEO4J_apoc_import_file_enabled=true \
    -e NEO4J_apoc_export_file_enabled=true \
    -e NEO4J_apoc_import_file_use__neo4j__config=true \
    -e NEO4J_PLUGINS='["graph-data-science", "apoc"]' \
    -e NEO4J_AUTH=neo4j/passwd123 \
    -e NEO4J_dbms_default__listen__address=0.0.0.0 \
    neo4j:latest

# 检查容器是否成功启动
if [ $? -eq 0 ]; then
    echo "容器 '$CONTAINER_NAME' 启动成功。"
    echo "HTTP 端口映射: 主机 $HTTP_PORT -> 容器 7474"
    echo "Bolt 端口映射: 主机 $BOLT_PORT -> 容器 7687"
else
    echo "错误: 容器 '$CONTAINER_NAME' 启动失败。"
    exit 1
fi