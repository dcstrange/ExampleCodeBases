import psycopg2
import os
import argparse
from pathlib import Path
import sys
from datetime import datetime
import json  # 添加json模块

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(project_root)

from config.database import DatabaseConfig 

# SQL查询字典，包含所有表的导出查询
EXPORT_QUERIES = {
    # === 节点表 ===
    'files': """
        SELECT
            id,
            path,
            file_hash,
            last_modified,
            is_deleted,
            source_code,
            annotation,
            semantic_explanation
        FROM files
    """,
    
    'functions': """
        SELECT
            id,
            name,
            def_loc,
            decl_loc,
            ret_type,
            is_static,
            op_source,
            source_code,
            annotation,
            semantic_explanation
        FROM functions
    """,
    
    'globals': """
        SELECT
            id,
            name,
            def_loc,
            decl_loc,
            is_static,
            is_extern,
            op_source,
            source_code,
            annotation,
            semantic_explanation
        FROM globals
    """,
    
    'types': """
        SELECT
            id,
            name,
            def_loc,
            decl_loc,
            kind,
            is_definition,
            is_function_pointer,
            op_source,
            source_code,
            annotation,
            semantic_explanation
        FROM types
    """,
    
    'macros': """
        SELECT
            id,
            name,
            def_loc,
            source_code,
            annotation,
            semantic_explanation
        FROM macros
    """,

    # === 关系表 ===
    'file_defines_function': """
        SELECT
            file_id AS start_id,
            function_id AS end_id
        FROM file_defines_function
    """,

    'file_declares_function': """
        SELECT
            file_id AS start_id,
            function_id AS end_id
        FROM file_declares_function
    """,

    'file_defines_global': """
        SELECT
            file_id AS start_id,
            global_id AS end_id
        FROM file_defines_global
    """,

    'file_declares_global': """
        SELECT
            file_id AS start_id,
            global_id AS end_id
        FROM file_declares_global
    """,

    'file_defines_type': """
        SELECT
            file_id AS start_id,
            type_id AS end_id
        FROM file_defines_type
    """,

    'file_declares_type': """
        SELECT
            file_id AS start_id,
            type_id AS end_id
        FROM file_declares_type
    """,

    'file_defines_macro': """
        SELECT
            file_id AS start_id,
            macro_id AS end_id
        FROM file_defines_macro
    """,

    'file_includes_file': """
        SELECT
            file_id AS start_id,
            included_file_id AS end_id
        FROM file_includes_file
    """,

    'function_function_rel': """
        SELECT
            caller_id AS start_id,
            callee_id AS end_id,
            relation_type
        FROM function_function_rel
    """,

    'function_uses_global': """
        SELECT
            function_id AS start_id,
            global_id AS end_id
        FROM function_uses_global
    """,

    'function_uses_type': """
        SELECT
            function_id AS start_id,
            type_id AS end_id
        FROM function_uses_type
    """,

    'function_uses_macro': """
        SELECT
            function_id AS start_id,
            macro_id AS end_id
        FROM function_uses_macro
    """,

    'global_uses_function': """
        SELECT
            global_id AS start_id,
            function_id AS end_id
        FROM global_uses_function
    """,

    'global_uses_global': """
        SELECT
            global_id AS start_id,
            other_global_id AS end_id,
            relation_type
        FROM global_uses_global
    """,

    'global_uses_type': """
        SELECT
            global_id AS start_id,
            type_id AS end_id
        FROM global_uses_type
    """,

    'global_uses_macro': """
        SELECT
            global_id AS start_id,
            macro_id AS end_id
        FROM global_uses_macro
    """,

    'type_uses_type': """
        SELECT
            type_id AS start_id,
            other_type_id AS end_id,
            relation_type
        FROM type_uses_type
    """,

    'type_uses_macro': """
        SELECT
            type_id AS start_id,
            macro_id AS end_id
        FROM type_uses_macro
    """
}

def export_table(conn, query, output_path, table_name, format='csv'):
    """导出单个表到CSV或JSON文件"""
    file_extension = format.lower()
    full_path = os.path.join(output_path, f"{table_name}.{file_extension}")
    try:
        with conn.cursor() as cur:
            if format.lower() == 'csv':
                with open(full_path, 'w') as f:
                    cur.copy_expert(f"COPY ({query}) TO STDOUT CSV HEADER", f)
            elif format.lower() == 'json':
                # 执行查询
                cur.execute(query)
                # 获取列名
                columns = [desc[0] for desc in cur.description]
                # 获取所有行
                rows = cur.fetchall()
                # 将行转换为字典列表
                data = [dict(zip(columns, row)) for row in rows]
                # 写入JSON文件
                with open(full_path, 'w') as f:
                    json.dump(data, f, indent=2, default=str)
            else:
                raise ValueError(f"Unsupported format: {format}")
            return True
    except Exception as e:
        print(f"Error exporting {table_name}: {e}")
        return False

def create_export_directory(base_path):
    """创建导出目录，使用时间戳"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    export_dir = os.path.join(base_path, f"export_{timestamp}")
    os.makedirs(export_dir, exist_ok=True)
    return export_dir

def main():
    parser = argparse.ArgumentParser(description='Export PostgreSQL tables to CSV or JSON files')
    parser.add_argument('--output', required=True, help='Output directory path')
    parser.add_argument('--tables', nargs='+', help='Specific tables to export (optional)')
    parser.add_argument('--verbose', action='store_true', help='Enable verbose output')
    parser.add_argument('--format', choices=['csv', 'json'], default='json', 
                        help='Export format: csv or json (default: json)')

    args = parser.parse_args()

    # 创建导出目录
    try:
        export_dir = create_export_directory(args.output)
        if args.verbose:
            print(f"Created export directory: {export_dir}")
    except Exception as e:
        print(f"Error creating export directory: {e}")
        return None

    try:
        # 从配置加载数据库设置
        db_config = DatabaseConfig.from_settings()
        if args.verbose:
            print(f"Connecting to database {db_config.dbname} on {db_config.host}:{db_config.port}")

        # 连接数据库
        conn = psycopg2.connect(
            dbname=db_config.dbname,
            user=db_config.user,
            password=db_config.password,
            host=db_config.host,
            port=db_config.port
        )

        # 确定要导出的表
        tables_to_export = args.tables if args.tables else EXPORT_QUERIES.keys()
        total_tables = len(tables_to_export)
        successful_exports = 0

        print(f"Starting export of {total_tables} tables...")

        # 导出每个表
        for i, table_name in enumerate(tables_to_export, 1):
            if table_name in EXPORT_QUERIES:
                if args.verbose:
                    print(f"[{i}/{total_tables}] Exporting {table_name} in {args.format} format...")
                
                if export_table(conn, EXPORT_QUERIES[table_name], export_dir, table_name, args.format):
                    successful_exports += 1
                    if args.verbose:
                        print(f"Successfully exported {table_name}")
            else:
                print(f"Warning: Table {table_name} not found in export queries")

        # 打印总结
        print(f"\nExport Summary:")
        print(f"Total tables: {total_tables}")
        print(f"Successfully exported: {successful_exports}")
        print(f"Failed: {total_tables - successful_exports}")
        print(f"Export directory: {export_dir}")

    except Exception as e:
        print(f"Error: {e}")
        return None
    finally:
        if 'conn' in locals():
            conn.close()
            if args.verbose:
                print("Database connection closed")

    return export_dir

if __name__ == "__main__":
    result = main()
    if result:
        print(f"{result}")
    else:
        print("Export failed.")